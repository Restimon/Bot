# 🎮 GotValis Bot - Complete Testing Guide

## 📋 Table of Contents
1. [Setup & Deployment](#setup--deployment)
2. [Feature Testing Checklist](#feature-testing-checklist)
3. [Item System Reference](#item-system-reference)
4. [Command Reference](#command-reference)
5. [Status Effects Reference](#status-effects-reference)
6. [Economy System](#economy-system)

---

## 🚀 Setup & Deployment

### Prerequisites
```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Add your DISCORD_TOKEN, MONGODB_URI, OPENAI_API_KEY

# Deploy slash commands
npm run deploy

# Start the bot
npm start
```

---

## ✅ Feature Testing Checklist

### 1. **Loot System** (Section 1.1)
**How it works:**
- Box appears every 5-15 random messages
- Bot ignores other bot messages
- 30-second reaction window
- First 5 users to react get items
- Items distributed after 30 seconds

**Test Steps:**
1. ✅ Send 5-15 messages in a channel
2. ✅ Wait for bot to add reaction (🎁) to a random message
3. ✅ Click the reaction within 30 seconds
4. ✅ Wait 30 seconds for box to open
5. ✅ Check `/inventaire` to see received items
6. ✅ Verify max 5 participants
7. ✅ Test that bot messages don't count toward message counter

**Expected:** Items appear in inventory, max 5 users rewarded

---

### 2. **Special Supply** (Section 1.2)
**How it works:**
- Random daily events (max 3 per day)
- Never between 00:00-06:30
- Minimum 3 hours between supplies
- Minimum 30 messages since last supply
- 5-minute window, first 5 react
- Rewards: items, tickets, 20-70 GotCoins, damage, healing, status effects

**Test Steps:**
1. ✅ Send 30+ messages in active channel
2. ✅ Wait for Special Supply embed to appear
3. ✅ React within 5 minutes
4. ✅ Check rewards (could be: items, tickets, coins, damage, heal, effects)
5. ✅ Verify max 3 per day restriction
6. ✅ Verify 3-hour gap between supplies
7. ✅ Test time restriction (no supply 00:00-06:30)

**Expected:** Random rewards, max 3/day, proper timing restrictions

---

### 3. **Daily Rewards** (Section 1.4)
**Command:** `/daily`

**Test Steps:**
1. ✅ Run `/daily`
2. ✅ Verify rewards:
   - 20-50 GotCoins (random)
   - 1 ticket
   - 3 items (can be duplicates)
3. ✅ Try `/daily` again (should show cooldown)
4. ✅ Do `/daily` next day to test streak
5. ✅ Verify streak bonus: +1 GC per streak day (max 20)
6. ✅ Test 48-hour grace period for streak

**Expected:** Daily rewards + streak system working

---

### 4. **Profile System** (Section 1.5)
**Command:** `/profile [@user]`

**Test Steps:**
1. ✅ Run `/profile`
2. ✅ Verify displayed info:
   - ❤️ HP (current/max)
   - 🛡️ Shield (if any)
   - 💰 GotCoins (current balance)
   - 💸 Total earned (lifetime)
   - 🎫 Tickets
   - 📅 Member since date
   - 🎭 Equipped character + passive
   - 📊 Leaderboard rank
   - 🎒 Inventory (first 12 items)
   - 🧪 Active status effects with time remaining
3. ✅ Check another user's profile: `/profile @username`

**Expected:** All stats accurately displayed

---

### 5. **Gacha/Invocation System** (Section 1.6)
**Commands:** `/summon`, `/collection`, `/equip`, `/unequip`, `/gacha_list`, `/gacha_is`, `/gacha_sell`

**Test Steps:**
1. ✅ Run `/gacha_list` to see all 10 characters
2. ✅ Get tickets via `/daily`
3. ✅ Run `/summon amount:1`
4. ✅ Verify character received (rarity: Common/Uncommon/Rare/Epic/Legendary)
5. ✅ Run `/collection` to see owned characters
6. ✅ Run `/equip character:[name]` to equip
7. ✅ Run `/gacha_is` to see equipped character
8. ✅ Try `/unequip` (1-hour cooldown)
9. ✅ Test `/gacha_sell character:[name]` for GotCoins
10. ✅ Test multiple summons: `/summon amount:5`

**Rarity Rates:**
- Common: 50%
- Uncommon: 30%
- Rare: 12%
- Epic: 6%
- Legendary: 2%

**Expected:** Gacha working, equip system, sell for coins

---

### 6. **GotValis AI Bot** (Section 1.7)
**How it works:**
- GotValis earns money from messages, damage dealt, shop purchases
- ChatGPT integration (15% reply chance)
- Always replies to mentions
- Participates in leaderboard

**Test Steps:**
1. ✅ Send normal messages (15% chance of AI reply)
2. ✅ Mention @GotValis (should always reply)
3. ✅ Check leaderboard - GotValis should appear
4. ✅ Buy items from shop - GotValis earns the purchase amount
5. ✅ Deal damage without target - GotValis earns the damage value
6. ✅ Sell items - GotValis loses money equal to sell value

**Expected:** AI responds, earns/loses money, appears on leaderboard

---

### 7. **Shop System** (Section 1.8)
**Commands:** `/boutique`, `/shop`, `/sell`, `/solde`

**Test Steps:**
1. ✅ Run `/solde` to check your GotCoins
2. ✅ Run `/boutique` to open interactive shop menu
3. ✅ Select item category from dropdown
4. ✅ Purchase items
5. ✅ Verify prices:
   - 🦠 Virus: 60 GC
   - 🧟 Infection: 70 GC
6. ✅ Run `/sell item:[emoji]` to sell items (60% of buy price)
7. ✅ Verify GotValis bot gains money from purchases
8. ✅ Verify GotValis bot loses money when you sell

**Expected:** Buy/sell working, correct prices, GotValis economy tracking

---

### 8. **Help Command** (Section 1.9)
**Command:** `/help`

**Test Steps:**
1. ✅ Run `/help`
2. ✅ Verify all command categories shown:
   - Profile & Stats
   - Economy
   - Gacha System
   - Combat
   - Social
   - Admin

**Expected:** Comprehensive help guide displayed

---

### 9. **Combat System** (Section 2.2)
**Command:** `/fight @target item:[emoji]`

**Test Steps:**
1. ✅ Get offensive items from shop or loot
2. ✅ Run `/fight @target item:❄️` (1 damage item)
3. ✅ Verify damage calculation shown in embed
4. ✅ Test critical hits (varies by item)
5. ✅ Test shield breaking:
   - Give target shield via `/use item:🛡️`
   - Attack and verify "Bouclier détruit" message
6. ✅ Test status effect items:
   - 🔥 Feu: 30% burn chance
   - 🦠 Virus: applies virus
   - 🧪 Poison: applies poison
   - 🧟 Infection: applies infection
7. ✅ Test AoE damage (☠️ Crâne: 24 main + 12 to 2 random)
8. ✅ Verify economy: +1 GC per damage dealt
9. ✅ Test KO: reduce target to 0 HP
   - Attacker gets +50 GC
   - Target loses -25 GC
   - Target respawns at 100 HP
   - Target's status effects purged

**Expected:** Damage, crits, shields, status effects, KO system working

---

### 10. **Healing System** (Section 2.3)
**Command:** `/heal item:[emoji] [@target]`

**Test Steps:**
1. ✅ Take damage from `/fight`
2. ✅ Self-heal: `/heal item:💊` (15 HP)
3. ✅ Verify embed format: "User se soigne de X ❤️"
4. ✅ Heal others: `/heal item:💊 @target`
5. ✅ Verify format: "User soigne @target de X ❤️"
6. ✅ Test all healing items:
   - 🍀 Trèfle: 1 HP (20% crit)
   - 🩹 Bandage: 5 HP (15% crit)
   - 🩸 Sang: 10 HP (10% crit)
   - 💊 Pilule: 15 HP (5% crit)
   - 💕 Régénération: applies regen status (2% crit)
7. ✅ Test critical heals (double amount)
8. ✅ Verify cannot overheal (max 100 HP)
9. ✅ Verify economy: +1 GC per HP healed

**Expected:** Healing working, self/target variants, crit heals, economy

---

### 11. **Status Effects** (Section 2.4)
**Tick System - Automatic every 30 seconds**

#### 🧪 Poison
- **Effect:** 1 damage per tick
- **Interval:** 30 minutes
- **Duration:** 3 hours
- **Source:** 🧪 Poison item
- **Extra:** Reduces attacker damage by -1

#### 🦠 Virus
- **Effect:** 5 damage per tick
- **Interval:** 1 hour
- **Duration:** 6 hours
- **Source:** 🦠 Virus item
- **Extra:** Transfers to target on attack

#### 🧟 Infection
- **Effect:** 5 damage per tick
- **Interval:** 30 minutes
- **Duration:** 3 hours
- **Source:** 🧟 Infection item
- **Extra:** +3 damage on attack, 25% chance to infect (5 damage)

#### 🔥 Burn
- **Effect:** 1 damage per tick
- **Interval:** 15 minutes
- **Duration:** 1 hour
- **Source:** 🔥 Fire item (30% chance)

#### 💕 Regeneration
- **Effect:** +2 HP per tick
- **Interval:** 30 minutes
- **Duration:** 5 hours
- **Source:** 💕 Regeneration item

**Test Steps:**
1. ✅ Apply each status effect
2. ✅ Wait for tick notifications in channel
3. ✅ Verify tick format: "User subit X dégâts (emoji)"
4. ✅ Verify calculation shown: "HP - damage = new HP"
5. ✅ Test virus transfer: infected user attacks → virus transfers
6. ✅ Test infection mechanics: 25% chance to spread
7. ✅ Test cure: `/use item:💉` removes all negative effects
8. ✅ Test KO purge: dying removes all effects

**Expected:** All status effects tick correctly, transfer/spread working

---

### 12. **Utility Items** (Section 2.1)
**Command:** `/use item:[emoji] [@target]`

#### 🎁 Gift Box
- Opens to reveal 3 items OR 2 items + 10-30 GotCoins
- Test: `/use item:🎁`

#### 🔍 Magnifying Glass
- Steals random item from target's inventory
- Test: `/use item:🔍 @target`

#### 💉 Syringe
- Cures virus, poison, and infection
- Test: `/use item:💉` (when infected)

#### 🛡️ Shield
- Grants 20 shield points
- Test: `/use item:🛡️`
- Verify: `/profile` shows shield

#### 👟 Running Shoes
- Doubles dodge chance for 6 hours
- Test: `/use item:👟`

#### 🪖 Helmet
- Reduces damage by 50% for 8 hours
- Test: `/use item:🪖`
- Verify: Get attacked, damage halved

#### ⭐ Star
- Total immunity (damage + status effects) for 5 hours
- Test: `/use item:⭐`
- Verify: Cannot be damaged or affected

**Expected:** All utility effects working

---

### 13. **Economy System** (Section 2.5)

**Income Sources:**
- ✅ **Messages:** +1-3 GC per message (15-second cooldown)
- ✅ **Voice:** +2-6 GC every 30 minutes in voice channel
- ✅ **Damage:** +1 GC per HP damage dealt
- ✅ **Healing:** +1 GC per HP healed
- ✅ **Kills:** +50 GC per kill
- ✅ **Daily:** +20-50 GC (+ streak bonus)
- ✅ **Loot/Supply:** Variable GC from events

**Expenses:**
- ❌ **Deaths:** -25 GC (never below 0)
- ❌ **Shop purchases:** Item cost

**Test Steps:**
1. ✅ Send messages (wait 15s between) - check `/solde`
2. ✅ Join voice channel, wait 30 min - check balance
3. ✅ Deal damage - verify +1 GC per HP
4. ✅ Heal someone - verify +1 GC per HP
5. ✅ Kill someone - verify +50 GC
6. ✅ Die - verify -25 GC
7. ✅ Run `/daily` - verify coins received
8. ✅ Buy from shop - verify deduction

**Expected:** All income/expense sources working correctly

---

### 14. **Leaderboard** (Section 2.6)
**Commands:** `/lb_set`, `/lb_refresh`, `/lb_stop` (admin only)

**Test Steps:**
1. ✅ Run `/lb_set limit:10` in a channel (admin)
2. ✅ Verify leaderboard message posted
3. ✅ Earn some GotCoins
4. ✅ Wait 5 minutes - verify auto-update
5. ✅ Run `/lb_refresh` to force update (admin)
6. ✅ Verify top 3 have medal emojis (🥇🥈🥉)
7. ✅ Verify GotValis bot appears if has coins
8. ✅ Test `/lb_set limit:20` for 20-player display
9. ✅ Run `/lb_stop` to remove leaderboard (admin)

**Expected:** Auto-updating leaderboard, shows top 10/20, GotValis included

---

### 15. **Voice & Message Tracking** (Section 2.7)
**Command:** `/info [@user]`

**Test Steps:**
1. ✅ Send messages in server
2. ✅ Join voice channel for a few minutes
3. ✅ Run `/info`
4. ✅ Verify shows:
   - Messages sent (last 7 days)
   - Voice time (last 7 days, in minutes/hours)
   - Server join date
   - Leaderboard rank
   - Total damage/heals/kills/deaths

**Expected:** Accurate 7-day activity tracking

---

### 16. **Inventory** (Section 3.0)
**Command:** `/inventaire` or `/inv`

**Test Steps:**
1. ✅ Collect items from loot/shop/daily
2. ✅ Run `/inventaire`
3. ✅ Verify items grouped by category:
   - ⚔️ Fight items
   - 💊 Heal items
   - 🎁 Utility items
4. ✅ Verify quantity shown for duplicates
5. ✅ Test pagination if > 12 items

**Expected:** Clean inventory display with categories

---

### 17. **Social Commands** (Section 9.0)
**Commands:** `/slap`, `/kiss`, `/hug`, `/pat`, `/bit`, `/punch`, `/love`, `/lick`

**Test Steps:**
1. ✅ Run `/slap @user`
2. ✅ Run `/kiss @user`
3. ✅ Run `/hug @user`
4. ✅ Run `/pat @user`
5. ✅ Run `/bit @user`
6. ✅ Run `/punch @user`
7. ✅ Run `/love @user`
8. ✅ Run `/lick @user`

**Expected:** Social interaction embeds/messages

---

## 📦 Item System Reference

### ⚔️ Offensive Items (10)
| Emoji | Name | Damage | Crit % | Special |
|-------|------|--------|--------|---------|
| ❄️ | Glace | 1 | 20% | - |
| ⚔️ | Épée | 3 | 17.5% | - |
| 🔥 | Feu | 5 | 15% | 30% burn chance |
| ⚡ | Éclair | 10 | 12.5% | - |
| 🔫 | Pistolet | 15 | 10% | - |
| 🧨 | Dynamite | 20 | 8% | - |
| ☠️ | Crâne | 24 | 5% | +12 AoE to 2 targets |
| 🦠 | Virus | 5 | 3% | Virus DoT, transferable |
| 🧪 | Poison | 0 | 2.5% | Poison DoT, -1 dmg reduction |
| 🧟 | Infection | 0 | 0% | Infection DoT, attack bonuses |

### 💊 Healing Items (5)
| Emoji | Name | Heal | Crit % | Special |
|-------|------|------|--------|---------|
| 🍀 | Trèfle | 1 | 20% | - |
| 🩹 | Bandage | 5 | 15% | - |
| 🩸 | Sang | 10 | 10% | - |
| 💊 | Pilule | 15 | 5% | - |
| 💕 | Régénération | 0 | 2% | +2 HP/30min for 5h |

### 🎁 Utility Items (7)
| Emoji | Name | Effect |
|-------|------|--------|
| 🎁 | Cadeau | 3 items OR 2 items + 10-30 GC |
| 🔍 | Loupe | Steal random item |
| 💉 | Seringue | Cure virus/poison/infection |
| 🛡️ | Bouclier | +20 shield points |
| 👟 | Chaussures | Double dodge 6h |
| 🪖 | Casque | -50% damage 8h |
| ⭐ | Étoile | Total immunity 5h |

---

## 🧪 Status Effects Reference

| Effect | Emoji | Tick Dmg/Heal | Interval | Duration | Special |
|--------|-------|---------------|----------|----------|---------|
| Poison | 🧪 | 1 dmg | 30 min | 3h | -1 dmg on attacker |
| Virus | 🦠 | 5 dmg | 1h | 6h | Transfers on attack |
| Infection | 🧟 | 5 dmg | 30 min | 3h | +3 dmg/attack, 25% spread |
| Burn | 🔥 | 1 dmg | 15 min | 1h | - |
| Regen | 💕 | +2 heal | 30 min | 5h | - |

---

## 📜 All Commands Reference

### 🎮 Core Gameplay
- `/fight @target item:[emoji]` - Attack a player
- `/heal item:[emoji] [@target]` - Heal self or target
- `/use item:[emoji] [@target]` - Use utility item

### 📊 Profile & Stats
- `/profile [@user]` - View profile
- `/info [@user]` - View detailed stats
- `/inventaire` or `/inv` - View inventory
- `/solde` - Check GotCoins balance

### 🎰 Gacha System
- `/summon amount:[1-10]` - Summon characters (costs tickets)
- `/collection` - View character collection
- `/equip character:[name]` - Equip character
- `/unequip` - Unequip character (1h cooldown)
- `/gacha_list` - See all available characters
- `/gacha_is` - See equipped character
- `/gacha_sell character:[name]` - Sell character for GC

### 💰 Economy
- `/daily` - Daily rewards (24h cooldown)
- `/boutique` - Interactive shop menu
- `/shop` - Shop commands
- `/sell item:[emoji]` - Sell items

### 🏆 Leaderboard (Admin)
- `/lb_set limit:[10/20]` - Set leaderboard in channel
- `/lb_refresh` - Force leaderboard update
- `/lb_stop` - Remove leaderboard

### 💬 Social
- `/slap @user` - Slap someone
- `/kiss @user` - Kiss someone
- `/hug @user` - Hug someone
- `/pat @user` - Pat someone
- `/bit @user` - Bite someone
- `/punch @user` - Punch someone
- `/love @user` - Show love
- `/lick @user` - Lick someone

### ℹ️ Help
- `/help` - Full command guide

---

## 🐛 Common Issues & Solutions

### Bot not responding to messages
- Check bot has `MESSAGE_CONTENT` intent enabled
- Verify bot has permission to read/send messages in channel

### Slash commands not appearing
- Run `npm run deploy` to register commands
- Wait up to 1 hour for Discord to sync
- Try `/` in a server channel (not DMs)

### Loot box not appearing
- Needs 5-15 messages from real users (not bots)
- Check bot has permission to add reactions
- Wait for random trigger

### Special Supply not spawning
- Needs 30+ messages in channel
- 3-hour minimum gap between supplies
- Max 3 per day
- Blocked 00:00-06:30

### Status effects not ticking
- Wait 30 seconds for ticker to run
- Check bot is online
- Verify channel still exists

### Leaderboard not updating
- Auto-updates every 5 minutes
- Use `/lb_refresh` to force update
- Verify message still exists (not deleted)

---

## 📝 Testing Checklist Summary

**Day 1 Testing:**
- [ ] Deploy bot and register commands
- [ ] Test loot system (15+ messages)
- [ ] Test `/daily` rewards
- [ ] Test `/profile` display
- [ ] Test `/summon` and gacha
- [ ] Test shop `/boutique`
- [ ] Test basic combat `/fight`
- [ ] Test healing `/heal`

**Day 2 Testing:**
- [ ] Test Special Supply (30+ messages, 3h gap)
- [ ] Test status effects (all 5 types)
- [ ] Test virus transfer
- [ ] Test infection spread
- [ ] Test utility items (all 7)
- [ ] Test KO/respawn system
- [ ] Test economy tracking

**Day 3 Testing:**
- [ ] Test leaderboard system
- [ ] Test voice tracking (30+ min)
- [ ] Test message tracking (7 days)
- [ ] Test `/info` stats
- [ ] Test GotValis AI replies
- [ ] Test GotValis economy
- [ ] Test selling items/characters

**Final Testing:**
- [ ] Multi-user combat scenarios
- [ ] Edge cases (0 HP, max shield, etc.)
- [ ] Long-term tracking (streaks, 7-day stats)
- [ ] Permission checks (admin commands)
- [ ] Error handling (invalid inputs)

---

## 🎯 Quick Start Testing (5 Minutes)

1. **Deploy:** `npm run deploy && npm start`
2. **Get items:** Send 15 messages → react to loot box
3. **Test combat:** `/fight @target item:❄️`
4. **Test shop:** `/boutique` → buy items
5. **Test gacha:** `/daily` → `/summon amount:1`
6. **Test profile:** `/profile`

---

**Good luck testing! Report any bugs in GitHub issues.**
